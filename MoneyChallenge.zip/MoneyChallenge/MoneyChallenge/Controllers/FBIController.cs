﻿using Microsoft.AspNetCore.Mvc;
using MoneyChallenge.Constants;
using MoneyChallenge.Data;
using MoneyChallenge.Interfaces;
using MoneyChallenge.Models;
using MoneyChallenge.Services;
using Swashbuckle.AspNetCore.Annotations;
using System.Diagnostics;

namespace MoneyChallenge.Controllers
{
    [Route("MoneyChallenge/[controller]")]
    [ApiController]
    public class FBIController : Controller
    {
        private readonly IFBIService _fbiService;
        private readonly FBIContext _dbContext;

        public FBIController(FBIService fbiService, FBIContext dbContext)
        {
            _fbiService = fbiService;
            _dbContext = dbContext;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [SwaggerOperation(Summary = FBIMessageSummary.GetWantedPeopleList)]
        public async Task<ActionResult<IEnumerable<FBIPerson>>> GetPersonFbi()
        {
            var wantedList = _fbiService.GetWantedPeopleList();

            if (wantedList == null)
            {
                return BadRequest("Não foi possivel obter lista de procurados do FBI");
            }

            _dbContext.AddRange(wantedList);
            await _dbContext.SaveChangesAsync();

            return Ok("Dados obtidos atraves da API do FBI e populado banco de dados com sucesso.");
        }
    }
}