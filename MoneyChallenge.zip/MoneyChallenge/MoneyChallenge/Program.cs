using Microsoft.EntityFrameworkCore;
using MoneyChallenge.Data;
using MoneyChallenge.Services;
using System.Net.Http.Headers;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("DatabaseConnection");
builder.Services.AddDbContext<FBIContext>(options => options.UseOracle(connectionString).EnableSensitiveDataLogging(true)
);

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
//    app.UseSwagger();
//    app.UseSwagger();
//}

void ConfigureServices(IServiceCollection services)
{
    services.AddHttpClient<FBIService>(client =>
    {
        client.BaseAddress = new Uri("https://api.fbi.gov/wanted/v1/");
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        // Another Header's there
        client.DefaultRequestHeaders.Add("HeaderName", "HeaderValue");
    });
}


app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();