﻿using MoneyChallenge.Models;

namespace MoneyChallenge.Interfaces
{
    public interface IFBIService
    {
        Task<List<FBIPerson>> GetWantedPeopleList();
    }
}
