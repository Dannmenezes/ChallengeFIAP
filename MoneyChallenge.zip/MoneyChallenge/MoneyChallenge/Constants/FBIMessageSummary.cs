﻿namespace MoneyChallenge.Constants
{
    public static class FBIMessageSummary
    {
        public const string GetWantedPeopleList = "Obter lista de procurados atraves da API do FBI e popular o banco de dados";
    }
}
