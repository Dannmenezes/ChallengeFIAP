﻿namespace MoneyChallenge.Models
{
    public class FBIPerson
    {
        public int Id { get; set; }
        public string? Titlte { get; set; }
        public string? Url { get; set; }
        public string? Sex { get; set; }
        public string? Description { get; set; }
        public string? Nationatily { get; set; }
    }
}
