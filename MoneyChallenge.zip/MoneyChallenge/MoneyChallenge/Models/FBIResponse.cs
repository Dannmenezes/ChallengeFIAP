﻿namespace MoneyChallenge.Models
{
    public class FBIResponse
    {
        public List<FBIPerson> Items { get; set; }
    }
}
